#include<bits/stdc++.h>
using namespace std;
int main()
{
    int m; //amount
    cin>>m;
    int n; //types of coin
    cin>>n;
    int coin[n];
    coin[0] = 0;
    for(int i=1;i<=n;i++)
    {
        cin>>coin[i];
    }
    int arr[n+1][m+1];
    for(int i=0; i<n+1; i++)
    {
        for(int j=0; j<m+1; j++)
        {
            if(i==0&&j==0 || j==0)
            {
                arr[i][j] = 0;
            }
            else if(i==0)
            {
                arr[i][j] = INT_MAX;
            }
            else if(j>=coin[i])
            {
                arr[i][j] = min(arr[i-1][j],1+arr[i][j-coin[i]]);
            }
            else
            {
                arr[i][j] = arr[i-1][j];
            }
        }
    }
    for(int i=0; i<n+1; i++)
    {
        for(int j=0; j<m+1; j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }
    vector<int>v;
    for(int i=n; i>=0; )
    {
        for(int j=m; j>=0; )
        {
            if(arr[i][j]==arr[i-1][j])
            {
                i--;
            }
            else
            {
                v.push_back(coin[i]);
                j = j - coin[i];
            }
        }
    }
    for(auto x:v)cout<<x<<" ";
}




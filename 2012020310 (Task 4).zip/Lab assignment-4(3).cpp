#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int arr[n];
    int LIS[n];
    for(int i=0; i<n; i++)
    {
        cin>>arr[i];
        LIS[i] = 1;
    }
    for(int i=1; i<n; i++)
    {
        for(int j=0; j<i; j++)
        {
            if(arr[i]>=arr[j])
            {
                LIS[i] = max(LIS[i],1+LIS[j]);
            }
        }
    }
    sort(LIS,LIS+n);
    cout<<LIS[n-1]<<endl;

}


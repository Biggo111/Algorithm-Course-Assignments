#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define check freopen("in.txt", "r", stdin);
#define biggo ios_base::sync_with_stdio(false);cin.tie(0),cout.tie(0)

const int n = 500;

int matrix[n][n];
int visit[n];

int main()
{
    cout<<"Enter the node number: ";
    int node;
    cin>>node;
    cout<<"Enter number of edges: ";
    int edge;
    cin>>edge;
    while(edge--)
    {
        int u,v;
        cin>>u>>v;
        matrix[u][v] = 1;
        matrix[v][u] = 1;
    }
    cout << "Enter root node: ";
    int r;
    cin >> r;
    stack<int>s;
    s.push(r);
    visit[r] = 1;

    cout << "DFS: ";
    while(!s.empty())
    {
        int u = s.top();//9
        cout << u << " ";
        s.pop();//1,4,3,10,9
        for(int i=1; i<=node; i++)
        {
            if(matrix[u][i] == 1)
            {
                if(visit[i] == 0)
                {
                    s.push(i);//2,3,
                    visit[i] = 1;//2,4,3,9,10
                }
            }
        }
    }
    return 0;
}

/*
DFS:
1: 2,4
2: 1,3,5,7,8
3: 2,4,9,10
4: 1,3
5: 2,6,7,8
6: 5
7: 2,5,8
8: 2,5,7
9: 3
10: 3

*/


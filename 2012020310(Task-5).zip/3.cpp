#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define check freopen("in.txt", "r", stdin);
#define biggo ios_base::sync_with_stdio(false);cin.tie(0),cout.tie(0)

const int n = 500;
vector<int>adj[n];
int visit[n],dis[n];
int main()
{
    int edge,node;
    cout<<"Enter total node: ";
    cin>>node;
    cout<<"Enter total edge: ";
    cin>>edge;
    while(edge--)
    {
        int u,v;
        cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    queue<int>q;
    q.push(1);
    visit[1] = 1;
    while(q.size())
    {
        int u = q.front();
        q.pop();
        for(auto i:adj[u])
        {
            if(visit[i]==1)continue;
            visit[i]=1;
            dis[i] = dis[u] + 1;
            q.push(i);
        }
    }
    int n;
    cout<<"Enter the node you want to measure the distance of : ";
    while(cin>>n)
    {
        cout<<"Distance is: "<<dis[n]<<endl;
    }
    return 0;
}


#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define check freopen("in.txt", "r", stdin);
#define biggo ios_base::sync_with_stdio(false);cin.tie(0),cout.tie(0)

const int n = 500;

vector<int>adj[n];
int visit[n];
int main()
{
    int node,edge;
    cout<<"Enter the number of nodes: ";
    cin>>node;
    cout<<"Enter the number of edges: ";
    cin>>edge;
    while(edge--)
    {
        int u,v;
        cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    cout << "Enter root node: ";
    int r;
    cin >> r;
    stack<int>s;
    s.push(r);
    visit[r] = 1;
    while(!s.empty())
    {
        int u = s.top();//5
        cout<<u<<" ";//1,4,3,10,9,2,8,7,5,6

        s.pop();//1,4,3,10,9,2,8,7,5,6
//        if(!visit[u])
//        {
//            visit[u] = 1;
//        }
        for(auto i:adj[u])
        {
            if(!visit[i])
            {
                s.push(i);//2,5,
                visit[i] = 1;//2,4,3,9,10,5,7,8,6
            }
        }
    }
    return 0;
}
/*
DFS:
1: 2,4
2: 1,3,5,7,8
3: 2,4,9,10
4: 1,3
5: 2,6,7,8
6: 5
7: 2,5,8
8: 2,5,7
9: 3
10: 3

*/


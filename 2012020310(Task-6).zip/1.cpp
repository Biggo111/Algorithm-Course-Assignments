#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define check freopen("in.txt", "r", stdin);
#define biggo ios_base::sync_with_stdio(false);cin.tie(0),cout.tie(0)
vector<int>graph[30];
int visit[1000];
int n,e;
vector<int>top_sort;
int x = -1;
int main()
{
    cin>>n>>e;
    int u,v;
    for(int i=1; i<=e; i++)
    {
        cin>>u>>v;
        graph[u].push_back(v);
        visit[v]++;
    }
    stack<int>s;
    for(int i=1; i<=n; i++)
    {
        if(visit[i]==0)
        {
            s.push(i);
        }
    }
    while(!s.empty())
    {
        int u = s.top();
        top_sort.push_back(u);
        s.pop();
        for(auto i: graph[u])
        {
            visit[i]--;
            if(visit[i]==0)
            {
                s.push(i);
            }
        }
    }
    for(auto x:top_sort)cout<<x<<" ";
}


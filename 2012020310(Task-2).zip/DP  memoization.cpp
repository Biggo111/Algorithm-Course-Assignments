#include<bits/stdc++.h>
using namespace std;

//vector<int>v;
int n;
int v[1000];
void val()
{
    for(int i=0;i<n+1;i++)
    {
        v[i] = -1 ;
        //v.push_back(-1);
    }
//    for(int i = 0;i<n;i++)
//    {
//        cout<<v[i]<<" ";
//    }
//    cout<<endl;
}
int fibb(int n)
{
    if(v[n]==-1)
    {
        if(n<=1)
        {
            v[n] = n;
        }
        else
        {
             v[n] = fibb(n-2) + fibb(n-1);
        }
    }
    return v[n];
}
int main()
{
    cin>>n;
    v[n+1];
    //v.resize(n+1);
    val();
    int a = fibb(n);
    cout<<a;
}

//Took some help of GFG
#include<bits/stdc++.h>
using namespace std;
int arr[1001][1001];
int LCS(string st,string st2,int l,int l2,int arr[][1001])
{
    if(l==0 || l2==0)
    {
        return 0;
    }
    if(arr[l-1][l2-1]!=-1)
    {
        return arr[l-1][l2-1];
    }
    if(st[l-1]==st2[l2-1])
    {
        arr[l-1][l2-1] = 1 + LCS(st,st2,l-1,l2-1,arr);
        return arr[l-1][l2-1];
    }
    else
    {
        arr[l-1][l2-1] = max(LCS(st,st2,l,l2-1,arr),LCS(st,st2,l-1,l2,arr));
        return arr[l-1][l2-1];
    }
}
int main()
{
    string st,st2;
    cin>>st>>st2;
    int l = st.size();
    int l2 = st2.size();
    arr[l+1][l2+1];
    memset(arr,-1,sizeof(arr));
    int lcs = LCS(st,st2,l,l2,arr);
    cout<<lcs;
}


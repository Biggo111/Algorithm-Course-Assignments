#include<bits/stdc++.h>
using namespace std;
void LIS (string st, string st2){
	int l = st.size();
    int l2 = st2.size();
    st = '\0' + st;
    st2 = '\0' + st2;
    int arr[l+1][l2+1];
    for(int i=0;i<l+1;i++)
    {
        for(int j=0;j<l2+1;j++)
        {
            if(i==0 || j==0)
            {
                arr[i][j]=0;
            }
            else if(st[i]==st2[j])
            {
                arr[i][j] = 1 + arr[i-1][j-1];
            }
            else
            {
                arr[i][j] = max(arr[i-1][j],arr[i][j-1]);
            }
        }
    }
    for(int i=0;i<l+1;i++)
    {
        for(int j=0;j<l2+1;j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }
    vector<char>v;
    for(int i=l;i>0;i--)
    {
        for(int j=l2;j>0;j--)
        {
            if(st[i]==st2[j])
            {
                v.push_back(st[i]);
                //cout<<st[i]<<endl;
                i--;
                j--;
            }
            else
            {
                 if(arr[i][j]==arr[i][j-1])
                 {
                     //cout<<arr[i][j]<<endl;
                     j--;
                 }
                 else if(arr[i][j]==arr[i-1][j])
                 {
                     //cout<<arr[i][j]<<endl;
                     i--;
                 }
            }
        }
    }
    reverse(v.begin(),v.end());
    for(auto x:v)cout<<x<<" ";
}


int main()

{
    string st,st2;
    cin>>st>>st2;
    LIS(st, st2);

}
